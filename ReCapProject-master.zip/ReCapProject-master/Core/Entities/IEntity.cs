﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entities
{
    //IEntity implement eden class bir veri tabanı tablosudur.
    public interface IEntity 
    {
    }
}
